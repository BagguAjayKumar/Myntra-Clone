const AWS = require('aws-sdk');
// Set the region and credentials if necessary
AWS.config.update({ region: 'eu-north-1', accessKeyId: 'AKIA47CR3EFKGQUQ6BQ7', secretAccessKey: '6z2EWvBOLP+u1/qEYxQpuOpGrt8gZtrS2zsqS0I9' });
// Create DynamoDB service object
const dynamodb = new AWS.DynamoDB();
// Example function to scan a table
async function scanTable(tableName) {
 try {
 const params = {
 TableName: tableName
 };
 const data = await dynamodb.scan(params).promise();
 console.log('Items in table', tableName + ':', data.Items);
 } catch (error) {
 console.error('Error:', error);
 }
}
// Call the function to scan a specific table
const tableName = 'Loki';
scanTable(tableName);
